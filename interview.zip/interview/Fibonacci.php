<html>
	<body>
		<h1> Fibonacci </h1>

		<form action="FibonacciCalc.php" method="GET" enctype="multipart/form-data" id="usrform">
			<input type="submit" value="Submit">
		</form>
		<br>
		<textarea rows="20" cols="50" name="comment" form="usrform">
5
7
11</textarea>
	</body>
</html>