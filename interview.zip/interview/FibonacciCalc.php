<?php
$number = $_GET['comment'];
$numbers = explode("\n", $number);
foreach($numbers as $num){
$num1 = Fib(strtolower($num));
print "$num1.<br>";
}

function Fib($number){
  $a = strval(0);
  $b = strval(1);
  for ($i = 0; $i < $number; $i++){
    $sum = add($a,$b);
    $a = $b;
    $b = $sum;
  }
  return $a;
}

function add($a, $b){
	$len1 = strlen($a);
	$len2 = strlen($b);
	
	if($len1 == 0){
		return $b;
	}
	if($len2 == 0){
		return $a;
	}
	$res = "";
	$carry = 0;
	while($len1 > 0 || $len2 > 0){
		$sum = $carry;
		if($len1 != 0){
			$sum += intval($a[$len1-1]);
			$len1--;
		}
		if($len2 != 0){
			$sum += intval($b[$len2-1]);
			$len2--;
		}
		$carry = floor($sum/10);
		$sum = $sum%10;
		$res = "$sum" . "$res";
	}
	if($carry != 0){
		$res = "$carry" . "$res";
	}	
	return $res;
}
?>