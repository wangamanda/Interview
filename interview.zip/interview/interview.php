<html>
	<head>
		<style type="text/css">
		body{
				padding-left: 15em;
				color: purple;
				background-color: #d8da3d	
		}
		ul.navbar {
			position: absolute;
			top: 2em;
			left: 1em;
			width: 9em;
			font-family: Georgia, "Times New Roman", Times, serif;
			color: purple;
			background-color: #d8da3d			}
		h1 {
		font-family: Helvetica, Geneva, Arial,
          SunSans-Regular, sans-serif }
		</style>
		
		<Title>Welcome Home</Title>
		
	</head>
	

		
	<body>
		<ul class = "navbar">
			<li> <a href = "interview.php"> Home Page </a>
			<li> <a href = "translator.php"> Translator </a>
			<li> <a href = "Fibonacci.php"> Fibonacci </a>
		</ul>
		
		<h1> Welcome Home </h1>
		<br />
		<h2> English-Number translator </h2>
		<h3> Input a number in english and you will get the integer representation. </h3>
		<h3>SAMPLE INPUT: six, negative seven hundred twenty nine, one million one hundred one</h3>
		<h3>SAMPLE OUTPUT: 6, -729, 1000101</h3>
		<br />
		<br />
		<h2> Fibonacci </h2>
		<h3> Calculate the Fibonacci Numbers. </h3>
		<h3>SAMPLE INPUT: 5, 7, 11</h3>
		<h3>SAMPLE OUTPUT: 5, 13, 89</h3>
		<br />
		<br />
		<br />
		<br />
		<br />
		<address> Xin Wang </address>
	</body>
</html>