<html>
	<body>
		<h1> English-Number translator </h1>

		<form action="translate.php" method="GET" enctype="multipart/form-data" id="usrform">

			<input type="submit" value="Submit">
		</form>
		<br>
		<textarea rows="20" cols="50" name="comment" form="usrform">
six
negative seven hundred twenty nine
one million one hundred one</textarea>
	</body>
</html>